//
//  Cell_HomeWork.swift
//  WhatTo
//
//  Created by macmini on 13/06/17.
//  Copyright © 2017 qw. All rights reserved.
//

import UIKit

class Cell_HomeWork: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lbl_placeAddress: UILabel!
    @IBOutlet weak var lbl_placeName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
