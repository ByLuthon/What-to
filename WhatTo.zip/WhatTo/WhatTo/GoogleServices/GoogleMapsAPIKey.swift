class GoogleMapsAPIKey {

    static let GMS_API_KEY = "AIzaSyDLQ3zm0BPJDDNsYxNDMr4PEjpg7t4eLLw"
    static let GEOCODING_API_KEY = "AIzaSyCyPjx8P653F_j8G-eazG-uHB9qCoq9N28"
    static let DIRECTION_API_KEY = "AIzaSyAdHWDDlZHsjcQ57azkCIFir7I3GhoN0wg"
    static let GMSPLACES_API_KEY = "AIzaSyDdUvFXxhLMpili_tspnE2QK7wkAHAoL3c"
    static let WEBSERVICE_API_KEY = "AIzaSyCciLNFURZzeC9qkRXpIRZeaK3KgDuWEe0"
    
    /*
    static let GMS_API_KEY = "AIzaSyCCOokOQ_nQamDAdVOWhMtRMOKZixlFMns"
    static let GEOCODING_API_KEY = "AIzaSyCCOokOQ_nQamDAdVOWhMtRMOKZixlFMns"
    static let DIRECTION_API_KEY = "AIzaSyCCOokOQ_nQamDAdVOWhMtRMOKZixlFMns"
    static let GMSPLACES_API_KEY = "AIzaSyCCOokOQ_nQamDAdVOWhMtRMOKZixlFMns"
    static let WEBSERVICE_API_KEY = "AIzaSyCCOokOQ_nQamDAdVOWhMtRMOKZixlFMns"*/

}
